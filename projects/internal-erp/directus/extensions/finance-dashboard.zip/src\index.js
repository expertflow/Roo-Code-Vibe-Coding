import ModuleComponent from './module.vue';

export default {
    id: 'finance-dashboard',
    name: 'Finance/Executive',
    icon: 'insights',
    routes: [
        {
            path: '',
            component: ModuleComponent,
        },
    ],
};
